export const instructorFileDirs = [{
    id: 1,
    name: 'certificates',
    dirName: 'תעודות',
}];